James Madison University Billiards Club Competitive Hub App

This app is designed to streamline the process of digital record keeping within the comptitive section of the club.
If you find any bugs or think of any features which could be useful to impliment, you can contact the app's developer, Jason, at jwklugh@comcast.net.

Initial use of the application requires signing in to a google account with appropriate permission to access the necessary Google Docs. The application will be labeled as QuickStart, and you will have to mark it as a trusted application.


The interface is broken into 4 primary sections: The rankings, Requested Challenges, Upcoming Challenges, and quick links. 

The Rankings Section is purely observational, and cannot be interacted with. 

Requested Challenges shows all challenges in the spreadsheet page meeting the condition of the approval field being blank. Double clicking a challenge in this section will prompt the user to assign an approving overseer, or to deny the match. Doing so will open a response sender interface with most or all information filled. If the challenge is denied, a reason is allowed to be expressed. In either case a preview can be reviewed and then sent. Regardless of a message being sent or not, the given approver or "denied" will be put into the approval field as appropriate automatially.

Upcoming Challenges shows all challenges in the spreadsheet meeting the condition of the approval field is filled, but the Winner field is blank (signifying the match has not had a result yet). Double clicking a challenge in this section will open a prompt allowing the user to open a scoreboard for the match, or to declare a winner for the match. Refer to the README in the Scoreboard app for its operation. Selecting to declare a winner will open a prompt to select Defender or Challenger. Selecting one will automatically update the leaderboard and records in the spreadsheet assuming names are correctly matching.